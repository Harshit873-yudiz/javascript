//global variable
var oldColor1,oldColor2,oldColor3,oldColor4;

//div 1 Screen1
function screen1(color1) {
   if (oldColor1) {
        document.getElementById("div1").style.backgroundColor = "white";
        oldColor1 = null;
   } else {
       oldColor1 = color1;
       document.getElementById("div1").style.backgroundColor = "yellow";
   }
}	

//div 2 Screen2
function screen2(color2) {
   if (oldColor2) {
        document.getElementById("div2").style.backgroundColor = "white";
        oldColor2 = null;
   } else {
       oldColor2 = color2;
       document.getElementById("div2").style.backgroundColor = "skyblue";
   }
}

//div 3 Screen3
function screen3(color3) {
   if (oldColor3) {
        document.getElementById("div3").style.backgroundColor = "white";
        oldColor3 = null;
   } else {
       oldColor3 = color3;
       document.getElementById("div3").style.backgroundColor ="green";
   }
}

//div 4 Screen4
function screen4(color4) {
   if (oldColor4) {
        document.getElementById("div4").style.backgroundColor = "white";
        oldColor4 = null;
   } else {
       oldColor4 = color4;
       document.getElementById("div4").style.backgroundColor = "red";
   }
}