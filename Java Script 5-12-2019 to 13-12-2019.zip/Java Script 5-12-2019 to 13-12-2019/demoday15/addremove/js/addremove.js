// Create a "close" button and append it to each list item
var myNodelist = document.getElementsByTagName("LI");
var i;
for (i = 0; i < myNodelist.length; i++) {
  var btn = document.createElement("button");
  var txt = document.createTextNode("x");
  btn.className = "close";
  btn.appendChild(txt);
  myNodelist[i].appendChild(btn);
}

// Click on a close button to hide the current list item
var close = document.getElementsByClassName("close");
var i;
for (i = 0; i < close.length; i++) {
  close[i].onclick = function() {
    var div = this.parentElement;
    div.parentNode.removeChild(div);
  }
}

// function to create add or remove data
function addremove() {
  var li = document.createElement("li");
  var inputValue = document.getElementById("myInput").value;
  var inputdata = document.createTextNode(inputValue);

  li.appendChild(inputdata);
  if (inputValue === '') {
    alert("Please Enter Data");
  } else {
    document.getElementById("udata").appendChild(li);
  }
  document.getElementById("myInput").value = "";

  var btn = document.createElement("button");
  var txt = document.createTextNode("x");
  btn.className = "close";
  btn.appendChild(txt);
  li.appendChild(btn);

  for (i = 0; i < close.length; i++) {
    close[i].onclick = function() {
      var div = this.parentElement;
      div.parentNode.removeChild(div);
    }
  }
}