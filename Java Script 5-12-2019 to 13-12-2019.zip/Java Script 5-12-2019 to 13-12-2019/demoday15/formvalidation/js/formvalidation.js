function ArrayForm(){
	var uname=document.getElementById("name").value;
	var password=document.getElementById("pwd").value;
	var checkbox=document.getElementsByName("check");
	var radiobtn=document.getElementsByName("optradio");
	var option=document.getElementById("myoption").value;
	var i;

	//UserName
	if(uname.length<3 || uname.length>12){
		document.getElementById("unamealert").innerHTML="Name should be min 3 max 12 char";
		// return false;
	}
	else{
		document.getElementById("unamealert").innerHTML="";
	}

	//Password
	if(password.length<3 || password.length>12){
		document.getElementById("passalert").innerHTML="password should be min 3 max 12 char";
		// return false;
	}
	else{
		document.getElementById("passalert").innerHTML="";
	}

	//checkbox
	for(i=0;i<checkbox.length;i++){
		if(checkbox[i].checked==true){
			break;
		}
	}
	if(i==checkbox.length){
		document.getElementById("ischeck").innerHTML="choose atleast one";
		// return false;
	}
	else{
		document.getElementById("ischeck").innerHTML="";
	}

	//radio button
	for(i=0;i<radiobtn.length;i++){
		if(radiobtn[i].checked==true){
			break;
		}
	}
	if(i==radiobtn.length){
		document.getElementById("radio").innerHTML="choose one";
		// return false;
	}
	else{
		document.getElementById("radio").innerHTML="";
	}	

	//option menu
	if(option==0){

		document.getElementById("optionmenu").innerHTML="select an option";
		 return false;
	}
	else{
		document.getElementById("optionmenu").innerHTML="";
	}	

		return true;  
}