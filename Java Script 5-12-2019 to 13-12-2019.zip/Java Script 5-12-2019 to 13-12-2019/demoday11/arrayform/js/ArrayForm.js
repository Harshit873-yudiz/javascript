function ArrayForm(){
	var inputValues=new Array();
	
	var name=document.getElementById("name").value;
	var email=document.getElementById("email").value;
	var pwd=document.getElementById("pwd").value;
	if(isNaN(name)){
		for (i in name) {
    	//get input value from user
        var singleVal1 = name[i].value;
			
				inputValues1.push(singleVal1);	   
		}	
	}
	if(isNaN(email)){
		for (i in email) {
    	//get input value from user
        var singleVal = email[i].value;
			
				inputValues.push(singleVal);
			   
		}
		document.getElementById("result").innerHTML =name+","+ email+","+pwd;	
	}
	else{
		alert("not string");
	}	
}