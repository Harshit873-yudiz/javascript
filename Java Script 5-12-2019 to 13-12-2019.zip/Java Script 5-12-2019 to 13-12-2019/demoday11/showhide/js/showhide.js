//MyFunction 1
function myFunction1() {
  var x = document.getElementById("title1");
  if (x.style.display == "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
//MyFunction 2
function myFunction2() {
  var x = document.getElementById("title2");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}