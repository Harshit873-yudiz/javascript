function nameclass() {
    var data = document.getElementsByClassName("uname")[0].value;
    var email = document.getElementById("email").value;
    var pwd = document.getElementById("pwd").value;
   
    document.getElementById('result').innerHTML = "UserName:"+data+"<br>"+"User Email:"+email
    +"<br>"+"Password: "+pwd;
    }
    
