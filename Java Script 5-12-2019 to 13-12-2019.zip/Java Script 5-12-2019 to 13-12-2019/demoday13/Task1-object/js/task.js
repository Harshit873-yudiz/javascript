var library = [
{
	author: 'Bill Gates',
	title: 'The Road Ahead',
	readingStatus: true
},
{
	author: 'Steve Jobs',
	title: 'Walter Isaacson',
	readingStatus: true
},
{
	author: 'Suzanne Collins',
	title: 'Mockingjay: The Final Book of The Hunger Games', 
	readingStatus: false
}
];

//display value
function Library() {
	var txt="";
	for(var i=0;i<library.length;i++){
		if(library[i].readingStatus==1){
			txt +="Author:"+library[i].author+"Title:"+library[i].title
		+"readingStatus:"+library[i].readingStatus+"<br>";
		}
	}
	document.getElementById("demo").innerHTML=txt;	
}	

//disply whole data
function Data() {
	var txt="";
	for(var i=0;i<library.length;i++){
		txt +="Author:"+library[i].author+"Title:"+library[i].title
		+"readingStatus:"+library[i].readingStatus+"<br>";
	}
	document.getElementById("data").innerHTML=txt;	
}	
