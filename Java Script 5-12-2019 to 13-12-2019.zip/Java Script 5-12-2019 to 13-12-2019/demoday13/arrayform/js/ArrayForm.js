function ArrayForm(){
	var inputValues=new Array();
	
	var name=document.getElementById("name").value;
	var email=document.getElementById("email").value;
	var pwd=document.getElementById("pwd").value;
	if(isNaN(name)){
		for (i in name) {
    	//get input value from user
        var singleVal1 = name[i].value;
			
				inputValues.push(singleVal1);	   
		}	
	}
	//functionpwd(pwd);
	if(isNaN(email)){
		for (i in email) {
    	//get input value from user
        var singleVal = email[i].value;
			
				inputValues.push(singleVal);
			   
		}
		document.getElementById("result").innerHTML ="UserName:"+name+"<br>"+"UserEmail:"+email+"<br>"+"UserPassword:"+pwd;
		return false;
	}
	else{
		alert("Enter Proper Value to Submit Form");
		return false;
	}	
}
/*function functionpwd(pwd){
	if (pwd!=null) {
		for (i in pwd) {
    	//get input value from user
        var singleVal = pwd[i].value;
				inputValues.push(singleVal);	   
		}
	}
	else{
			alert("enter value");
		}
}*/