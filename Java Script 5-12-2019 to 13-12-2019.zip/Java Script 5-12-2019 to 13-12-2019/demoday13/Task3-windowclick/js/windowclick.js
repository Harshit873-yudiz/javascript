var userclick=0;
window.onclick = function () {
	userclick++
	document.getElementById('windowclick').value=userclick;
}
