function formdata(){
	
	var name=document.getElementById("name").value;
	var email=document.getElementById("email").value;
	var pwd=document.getElementById("pwd").value;
	
	var person= {Name:name, Email:email,Pwd:pwd};
	/*for(var i in person){
			console.log(person);
	}*/
	console.log(person);
	
}