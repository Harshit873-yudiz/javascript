
function calculator() {
			var num1=parseInt(document.getElementById('num1').value);
			var num2=parseInt(document.getElementById('num2').value);
	
			if(document.getElementById('op1').checked){
					document.getElementById("demo").innerHTML = "Add:"+(num1+num2);
			}
			if(document.getElementById('op2').checked){
					document.getElementById("demo").innerHTML = "Sub:"+(num1-num2);
			}
			if(document.getElementById('op3').checked){
					document.getElementById("demo").innerHTML = "Min:"+(num1*num2);
			}
			if(document.getElementById('op4').checked){
					document.getElementById("demo").innerHTML = "Div:"+(num1/num2);
			}
		}