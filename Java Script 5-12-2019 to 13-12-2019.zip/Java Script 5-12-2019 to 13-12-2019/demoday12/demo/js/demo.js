function Function_Return1() {
	var x=5,y=6,z;
	z=x+y;
	document.getElementById('Function_Return').innerHTML=z;
}

