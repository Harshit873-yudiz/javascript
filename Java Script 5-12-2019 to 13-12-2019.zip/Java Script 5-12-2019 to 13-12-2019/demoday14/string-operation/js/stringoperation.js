//count string length
function strlen(){
	var str=document.getElementById("strvalue").value;
	var arr={Str:str};
	document.getElementById("displaystrlen").innerHTML="String to array is:"+arr.Str.split(" ")+"<br>"+"String Length is:"+str.length;
}