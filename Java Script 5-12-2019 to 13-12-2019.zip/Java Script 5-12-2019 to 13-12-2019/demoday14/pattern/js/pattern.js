//right pattern
function rightpattern(){
	var num = 5,i,j;
	for (i=0;i<num;i++) {
        var str = "";
        for (j=0;j<num;j++) {
        	if (j >= num-i-1) {
                str =str+ "*";
            } 
            else {
                str=str+ " ";
            }
        }
        console.log(str);
	}
}

//user input pattern
function upattern(){
	var num=document.getElementById("unumber").value;
	var i,j,k,l,m,n;
	//left side pattern
	document.write("left to right <br> <br>");
	for(i=1;i<=num;i++){
		for(j=1;j<=i;j++){
			document.write("* ");
		}
		document.write("<br>");
	}
	//bottom to top
	document.write("<br>");
	document.write("top to bottom <br> <br>")
	for(k=num;k>=1;k--){
		for(l=1;l<=k;l++){
			document.write("* ");
		}
		document.write("<br>");
	}
}

//number pattern
function numpattern() {
	var row =5,print="",i,j;
	for (i = 1; i <= row; i++) {
		for (j = 1; j <= i; j++) {
			print+=j + " ";
		}
		console.log(print);
		print="";
	}	
}
//arrow pattern
function arrow(){
	var num=document.getElementById("arrowpattern").value;
	var i,j,k,l,m,n;
	for(i=1;i<=num;i++){
		for(j=1;j<i;j++){
			document.write("* ");
		}
		document.write("<br>");
	}
	for(k=num;k>=1;k--){
		for(l=1;l<=k;l++){
			document.write("* ");
		}
		document.write("<br>");
	}
}