//global var
var arr=[5,7,2,9,6];

//array add
function arrayadd(){
	var array={Array:arr};     //print array object in console 
	var i,sum=0;
	for(i=0;i<arr.length;i++){
		sum=sum+arr[i];
	}
   	console.log(array);	
	console.log("Total array sum=",sum);	
}
//array sort
function arraysort(){
	document.getElementById("bsort").innerHTML="Before Sort:"+arr;
	var sorted= arr.sort();
	document.getElementById("asort").innerHTML="After Sort:"+sorted;
	/*
	var i,j;
	for(i=0; i<arr; i++){
		for(j=0; j<arr-i-1; j++){
			if(arr[j] > arr[j+1]){
				var t;
				t= arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=t;
			}
		}
	}*/
}