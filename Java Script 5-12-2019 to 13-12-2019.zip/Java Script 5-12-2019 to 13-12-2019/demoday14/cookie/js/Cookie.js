//create cookie
function cookiename(){
	var setcookie = document.uform.setcookiename.value;
    document.cookie="Name=" + setcookie;
    document.write ("Cookies Name="+ setcookie );
}
//get created cookie
function ReadCookie()
{
   var getcookie = document.cookie;
   document.write ("Get created Cookie " + getcookie+"<br>");
   
   // Get all the cookies pairs in an array
   var arr = getcookie.split(" ");
   document.write(arr);
}