//arithmatic operator
function arithmaticoperator(){
	var x = 100,y= 50;
	var a=3;
	document.getElementById("arithmatic").innerHTML = "x=100 y=50"+"<br>"+"Add:"+(x+y)+"<br>"+"sub:"+(x-y)+"<br>"+"mul:"+(x*y)+"<br>"+"div:"+(x/y)+"<br>";
    
    document.getElementById("arithmaticexpression").innerHTML ="Add and mult:"+(x+y)*a;											  
}
//assignment operator
function assignmentoperator(){
	var x = 10;
	document.getElementById("assignmentadd").innerHTML ="Add:"+(x+=5);
	var y = 10;
	document.getElementById("assignmentsub").innerHTML = "Div:"+(y-=5);
	var z = 10;
	document.getElementById("assignmentmul").innerHTML = "Div:"+(z*=5);
	var w = 10;
	document.getElementById("assignmentdiv").innerHTML = "Div:"+(w/=5);
	var a = 10;
	document.getElementById("assignmentmod").innerHTML = "Div:"+(a%=5);
}
//comparision operator
function comparisionoperator(){
	var x = 5,y=5 ,z=5,w=20;
	document.getElementById("equaltoone").innerHTML = "check x==y or not:"+(x == y);
	document.getElementById("equaltotwo").innerHTML = "check quoted value z=='5' or not:" +(z == "50");
	document.getElementById("equaltypeone").innerHTML ="equal value and type ===:"+ (z === 5);
	document.getElementById("equaltypetwo").innerHTML ="check quoted value z==='5' or not:"+ (z === "5");
	document.getElementById("notequaltoone").innerHTML = "check x!=55 or not:"+(x!=55);
	document.getElementById("gt").innerHTML = "check x > w:"+(x>w);
	document.getElementById("lt").innerHTML = "check x < w:"+(x<w);
}
//logical opertor
function logicaloperator(){
		var x=10,y=5;
		document.getElementById("logicaland").innerHTML="check (x<15 && y>2):"+(x<15 && y>2)+"<br>"
		+"check (x<15 && y<2):"+(x<15 && y<2);
		document.getElementById("logicalor").innerHTML="check (x==10 || y==5):"+(x==10 || y==5)+"<br>"
		+"check (x==5 || y==6):"+(x==5 || y==6);
		document.getElementById("logicalnot").innerHTML="check (x!=y):"+(x!=y)+"<br>";
	}	
//conditional operator
function conditionaloperator(){
	var data;
  	var time = new Date();
  	if (time <=10) {
    	data = "Good morning";
  	} else if (time <= 18) {
    	data= "Good day";
  	} else {
    	data = "Good evening";
  	}
  	document.getElementById("condition").innerHTML = data;	
}